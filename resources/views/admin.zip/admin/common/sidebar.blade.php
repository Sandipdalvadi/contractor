
<nav class="pcoded-navbar">
    <div class="pcoded-inner-navbar main-menu">
        <ul class="pcoded-item pcoded-left-item">
            <li class="active">
                <a href="{{route('admin.home')}}">
                    <span class="pcoded-micon"><i class="zmdi zmdi-home"></i></span>
                    <span class="pcoded-mtext">Dashboard</span>
                </a>
            </li>
            <li class="active">
                <a href="{{route('admin.category.index')}}">
                    <span class="pcoded-micon"><i class="zmdi zmdi-home"></i></span>
                    <span class="pcoded-mtext">Category</span>
                </a>
            </li>
        </ul>
        
    </div> <!-- main-menu -->
</nav> <!-- pcoded-navbar -->
<!-- Side-Nav-->