<?php
return [
    'welcome'=> 'Welcome',
    'contractor'=> 'Contractor',
    'adminHome'=> 'Admin Home',
    'dashboard'=> 'Dashboard',
    'languages'=> 'Languages',
    'settings'=> 'Settings',
    'logout'=> 'Logout',
    'category'=> 'Category',
];