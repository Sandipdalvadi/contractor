<!-- Side-Nav-->
<aside class="main-sidebar hidden-print" id="test">
    <section class="sidebar">
        <ul class="sidebar-menu">
            <li><a href="{{route('admin.home')}}"><i class="fa fa-dashboard"></i><span>{{Lang::get('messages.dashboard')}}</span></a></li>
            <li><a href="{{route('admin.category.index')}}"><i class="fa fa-dashboard"></i><span>{{Lang::get('messages.category')}}</span></a></li>
        </ul>
    </section>
</aside>