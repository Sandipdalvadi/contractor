<!--Footer Area-->
<div class="container-fluid footer">
    <div class="row">
    <div class="container main-container-home">
        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
            <h3>Pages</h3>
            <ul class="list-group">
                <li><a href="#">Browse jobs</a></li>
                <li><a href="#">How it works</a></li>
                <li><a href="#">Plans & Prices</a></li>
                <li><a href="#">Companies</a></li>
                <li><a href="#">Contact us</a></li>
            </ul>
        </div>
        <!---Footer Column 01-->
        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
            <h3>Other page</h3>
  <ul class="list-group">
                <li><a href="#">Login/Register</a></li>
                <li><a href="#">Payment</a></li>
                <li><a href="#">Sumbit resume</a></li>
                <li><a href="#">Resume</a></li>
                <li><a href="#">Terms and conditions</a></li>

            </ul>
        </div>
         <!---Footer Column 01-->
   <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
            <h3>Contact with us</h3>
                      <p>Manchester Road 123-78B, <br/>Silictown</p> 
                <p>+46 123 456 789</p>
                <p>hello@sitename.com</p>
        </div>
         <!---Footer Column 01-->
        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
            <h3>About us</h3>
            <p>An employment website is a web site that deals specifically with employment or careers. Many employment websites are designed to allow employers to post job requirements for a position to be filled and are commonly known as job boards</p>
        </div>
        
    </div>
    </div>
</div>
<!--Footer Area--> 
<!--Last Footer Area---->
<div class="container-fluid footer last-footer">
    <div class="row">
        <div class="container main-container">
            <div class="col-lg-9 col-md-3 col-sm-9 col-xs-6" >
                <p class="copyright">© copyright 2020 | All Rights Reserved.</p>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-6">
                <ul class="list-group">
                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fa fa-google-plus-square"></i></a></li>
                    <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!--Last Footer Area----> 
