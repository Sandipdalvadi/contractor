<!DOCTYPE html>
<html lang="en">
    @include('user.common.style')
    <body>
        @include('user.common.header')
        @yield('content')
        @include('user.common.footer')
        @include('user.common.script')
                    

	</body>
</html>